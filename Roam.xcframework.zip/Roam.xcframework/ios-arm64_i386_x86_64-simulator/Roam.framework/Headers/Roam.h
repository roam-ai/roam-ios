//
//  Roam.h
//  Roam
//
//  Created by GeoSpark Mac 15 on 30/03/21.
//

#import <Foundation/Foundation.h>

//! Project version number for Roam.
FOUNDATION_EXPORT double RoamVersionNumber;

//! Project version string for Roam.
FOUNDATION_EXPORT const unsigned char RoamVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Roam/PublicHeader.h>


